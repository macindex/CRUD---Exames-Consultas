export interface Professor {
  id: string
  nome: string;
  sobreNome: string;
  email: string;
  senha: string

}

export interface Login {

  email: string;
  senha: string;


}
